import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Attendance from './components/Attendance';
import Leads from './components/Leads';
import Deals from './components/Deals';
import Contacts from './components/Contacts';
import TasksAndProjects from './components/TasksAndProjects';
import Reports from './components/Reports';
import Settings from './components/Settings';

// --- Theme Context ---
type Theme = 'light' | 'dark' | 'system';
interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within a ThemeProvider");
  return context;
};


// --- Data Models (Việt hóa) ---
export interface User { id: number; name: string; email: string; role: 'Quản trị viên' | 'Nhân viên'; avatar: string; }
export type LeadStatus = 'Mới' | 'Đang chăm sóc' | 'Tiềm năng' | 'Không tiềm năng';
export interface Lead { id: number; name: string; company: string; email: string; phone: string; status: LeadStatus; }
export type DealStatus = 'Khám phá' | 'Trình bày' | 'Thương lượng' | 'Thắng' | 'Thua';
export interface Deal { id: number; name: string; company: string; value: number; stage: DealStatus; closeDate: string; }
export interface Contact { id: number; name: string; company: string; email: string; phone: string; role: string; }
export type TaskStatus = 'Cần làm' | 'Đang làm' | 'Chờ duyệt' | 'Hoàn thành';
export interface Task { id: number; title: string; description: string; assignee: string; relatedPeople?: string[]; dueDate: string; status: TaskStatus; }
export interface AttendanceEntry { type: 'Check In' | 'Check Out'; time: Date; location?: string; }
export interface Notification { id: number; message: string; time: string; read: boolean; }


// --- Initial Data (Việt hóa) ---
const initialUsers: User[] = [
    { id: 1, name: 'Quản trị viên', email: 'admin@lavis.com', role: 'Quản trị viên', avatar: 'https://picsum.photos/id/1005/100/100' },
    { id: 2, name: 'Nhân viên A', email: 'nhanvien.a@lavis.com', role: 'Nhân viên', avatar: 'https://picsum.photos/id/1011/100/100' },
];
const initialLeadsData: Lead[] = [
  { id: 1, name: 'John Doe', company: 'Innovate Inc.', email: 'john.d@innovate.com', phone: '555-1234', status: 'Mới' },
  { id: 2, name: 'Jane Smith', company: 'Solutions Co.', email: 'jane.s@solutions.co', phone: '555-5678', status: 'Đang chăm sóc' },
  { id: 3, name: 'Peter Jones', company: 'MegaCorp', email: 'peter.j@megacorp.com', phone: '555-8765', status: 'Tiềm năng' },
];
const initialDealsData: Deal[] = [
    { id: 1, name: 'Thiết kế lại Website', company: 'Innovate Inc.', value: 25000, stage: 'Trình bày', closeDate: '2024-08-15' },
    { id: 2, name: 'Chiến dịch Marketing', company: 'Solutions Co.', value: 15000, stage: 'Thương lượng', closeDate: '2024-07-30' },
    { id: 3, name: 'Di chuyển lên Cloud', company: 'MegaCorp', value: 75000, stage: 'Khám phá', closeDate: '2024-09-01' },
    { id: 4, name: 'Phát triển ứng dụng', company: 'AlphaTech', value: 50000, stage: 'Thắng', closeDate: '2024-06-20' },
];
const initialContactsData: Contact[] = [
  { id: 1, name: 'Alice Johnson', company: 'Innovate Inc.', email: 'alice.j@innovate.com', phone: '555-1111', role: 'CEO' },
  { id: 2, name: 'Bob Williams', company: 'Solutions Co.', email: 'bob.w@solutions.co', phone: '555-2222', role: 'Quản lý dự án' },
];
const initialTasksData: Task[] = [
    {id: 1, title: 'Soạn thảo đề xuất cho Innovate Inc.', description: 'Chuẩn bị tài liệu đề xuất V2 cho hợp đồng thiết kế lại website.', assignee: 'Quản trị viên', dueDate: '2024-08-01', status: 'Đang làm'},
    {id: 2, title: 'Liên hệ lại với Jane Smith', description: 'Gọi cho Jane để thảo luận về chiến dịch marketing.', assignee: 'Quản trị viên', dueDate: '2024-07-28', status: 'Cần làm'},
    {id: 3, title: 'Onboard team AlphaTech', description: 'Lên lịch họp khởi động dự án phát triển ứng dụng mới.', assignee: 'Quản trị viên', dueDate: '2024-07-25', status: 'Hoàn thành'},
     {id: 4, title: 'Review báo cáo tháng', description: 'Xem xét và duyệt báo cáo công việc tháng 7.', assignee: 'Nhân viên A', dueDate: '2024-08-02', status: 'Chờ duyệt'},
];

const App: React.FC = () => {
  const [theme, setThemeState] = useState<Theme>(() => (localStorage.getItem('theme') as Theme) || 'system');
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [currentUser, setCurrentUser] = useState<User>(initialUsers[0]);
  const [leads, setLeads] = useState<Lead[]>(initialLeadsData);
  const [deals, setDeals] = useState<Deal[]>(initialDealsData);
  const [contacts, setContacts] = useState<Contact[]>(initialContactsData);
  const [tasks, setTasks] = useState<Task[]>(initialTasksData);
  const [isCheckedIn, setIsCheckedIn] = useState(false);
  const [attendanceLog, setAttendanceLog] = useState<AttendanceEntry[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([
      {id: 1, message: "Một khách hàng tiềm năng mới đã được thêm: Peter Jones.", time: "1 giờ trước", read: false},
      {id: 2, message: "Trạng thái công việc 'Onboard team AlphaTech' đã được cập nhật thành Hoàn thành.", time: "3 giờ trước", read: false},
      {id: 3, message: "Bạn đã Check In thành công.", time: "Hôm qua", read: true},
  ]);

  useEffect(() => {
    const root = window.document.documentElement;
    const isDark =
      theme === 'dark' ||
      (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    root.classList.toggle('dark', isDark);
  }, [theme]);

  const setTheme = (newTheme: Theme) => {
    localStorage.setItem('theme', newTheme);
    setThemeState(newTheme);
  };
  
  const addNotification = (message: string) => {
    const newNotif: Notification = {
        id: Date.now(),
        message,
        time: "Vừa xong",
        read: false
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleAddLead = (lead: Omit<Lead, 'id'>) => {
      setLeads(prev => [...prev, { ...lead, id: Date.now() }]);
      addNotification(`Khách hàng mới được thêm: ${lead.name}`);
  };
  const handleImportLeads = (importedLeads: Omit<Lead, 'id'>[]) => {
    const newLeads = importedLeads.map(lead => ({ ...lead, id: Date.now() + Math.random() }));
    setLeads(prev => [...prev, ...newLeads]);
    addNotification(`Đã nhập ${newLeads.length} khách hàng mới từ file CSV.`);
  };
  
  const handleAddDeal = (deal: Omit<Deal, 'id'>) => {
      setDeals(prev => [...prev, { ...deal, id: Date.now() }]);
      addNotification(`Cơ hội mới được tạo: ${deal.name}`);
  };
  const handleUpdateDealStage = (dealId: number, newStage: DealStatus) => {
    setDeals(prev => prev.map(deal => deal.id === dealId ? { ...deal, stage: newStage } : deal));
  };

  const handleAddContact = (contact: Omit<Contact, 'id'>) => setContacts(prev => [...prev, { ...contact, id: Date.now() }]);
  
  const handleAddTask = (task: Omit<Task, 'id' | 'status'>) => {
      setTasks(prev => [...prev, { ...task, id: Date.now(), status: 'Cần làm' }]);
      addNotification(`Công việc mới được giao: ${task.title}`);
  };
  const handleUpdateTaskStatus = (taskId: number, newStatus: TaskStatus) => {
      setTasks(prev => prev.map(task => task.id === taskId ? { ...task, status: newStatus } : task));
  };

  const handleCheckInToggle = (location?: string) => {
      const newStatus = !isCheckedIn;
      setIsCheckedIn(newStatus);
      const logEntry: AttendanceEntry = { type: newStatus ? 'Check In' : 'Check Out', time: new Date() };
      if (newStatus && location) {
        logEntry.location = location;
      }
      setAttendanceLog(prev => [logEntry, ...prev]);
      addNotification(`Bạn đã ${newStatus ? 'Check In' : 'Check Out'}.`);
  };
  
  const handleAddUser = (user: Omit<User, 'id' | 'avatar'>) => {
      const newUser = { ...user, id: Date.now(), avatar: `https://picsum.photos/seed/${Date.now()}/100/100`};
      setUsers(prev => [...prev, newUser]);
      addNotification(`Người dùng mới đã được tạo: ${user.name}`);
  }

  const handleUpdateCurrentUser = (data: { name: string; email: string; avatarFile?: File }) => {
    const { name, email, avatarFile } = data;

    const updateUser = (avatarUrl: string) => {
        const updatedUser: User = { ...currentUser, name, email, avatar: avatarUrl };
        setCurrentUser(updatedUser);
        setUsers(prevUsers => prevUsers.map(u => u.id === currentUser.id ? updatedUser : u));
        addNotification("Hồ sơ của bạn đã được cập nhật.");
    };

    if (avatarFile) {
        const reader = new FileReader();
        reader.onloadend = () => {
            updateUser(reader.result as string);
        };
        reader.readAsDataURL(avatarFile);
    } else {
        updateUser(currentUser.avatar); // Keep old avatar
    }
  };

  const handleUpdateUserRole = (userId: number, role: 'Quản trị viên' | 'Nhân viên') => {
      setUsers(prevUsers => prevUsers.map(u => {
          if (u.id === userId) {
            addNotification(`Đã cập nhật vai trò cho ${u.name} thành ${role}.`);
            return { ...u, role };
          }
          return u;
      }));
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      <HashRouter>
        <div className="flex h-screen bg-background text-foreground font-sans">
          <Sidebar currentUser={currentUser} />
          <div className="flex-1 flex flex-col overflow-hidden">
            <Header currentUser={currentUser} notifications={notifications} setNotifications={setNotifications} />
            <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background">
              <div className="container mx-auto px-6 py-8">
                <Routes>
                  <Route path="/" element={<Navigate to="/dashboard" replace />} />
                  <Route path="/dashboard" element={<Dashboard leads={leads} deals={deals} tasks={tasks} isCheckedIn={isCheckedIn} onCheckInToggle={handleCheckInToggle} attendanceLog={attendanceLog} />} />
                  <Route path="/attendance" element={<Attendance isCheckedIn={isCheckedIn} onToggleCheckIn={handleCheckInToggle} log={attendanceLog} />} />
                  <Route path="/leads" element={<Leads leads={leads} onAddLead={handleAddLead} onImportLeads={handleImportLeads} />} />
                  <Route path="/deals" element={<Deals deals={deals} onAddDeal={handleAddDeal} onUpdateDealStage={handleUpdateDealStage} />} />
                  <Route path="/contacts" element={<Contacts contacts={contacts} onAddContact={handleAddContact} />} />
                  <Route path="/tasks-projects" element={<TasksAndProjects tasks={tasks} users={users} onAddTask={handleAddTask} onUpdateTaskStatus={handleUpdateTaskStatus} />} />
                  <Route path="/reports" element={<Reports deals={deals} tasks={tasks} leads={leads} />} />
                  <Route path="/settings" element={
                    <Settings 
                      users={users} 
                      onAddUser={handleAddUser}
                      currentUser={currentUser}
                      onUpdateCurrentUser={handleUpdateCurrentUser}
                      onUpdateUserRole={handleUpdateUserRole}
                    />} 
                  />
                </Routes>
              </div>
            </main>
          </div>
        </div>
      </HashRouter>
    </ThemeContext.Provider>
  );
};

export default App;