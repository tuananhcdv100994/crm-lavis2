
import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Dashboard from './components/Dashboard';
import Attendance from './components/Attendance';
import Leads from './components/Leads';
import Deals from './components/Deals';
import Contacts from './components/Contacts';
import TasksAndProjects from './components/TasksAndProjects';
import Reports from './components/Reports';
import Settings from './components/Settings';
import Login from './components/Login';

// --- Theme Context ---
type Theme = 'light' | 'dark' | 'system';
interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
}
const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error("useTheme must be used within a ThemeProvider");
  return context;
};


// --- Data Models (Việt hóa) ---
export interface User { id: number; name: string; email: string; role: 'Quản trị viên' | 'Nhân viên'; avatar: string; }
export type LeadStatus = 'Mới' | 'Đang chăm sóc' | 'Tiềm năng' | 'Không tiềm năng';
export interface Lead { id: number; name: string; company: string; email: string; phone: string; status: LeadStatus; }
export type DealStatus = 'Khám phá' | 'Trình bày' | 'Thương lượng' | 'Thắng' | 'Thua';
export interface Deal { id: number; name: string; company: string; value: number; stage: DealStatus; closeDate: string; }
export interface Contact { id: number; name: string; company: string; email: string; phone: string; role: string; }
export type TaskStatus = 'Cần làm' | 'Đang làm' | 'Chờ duyệt' | 'Hoàn thành';
export interface Task { id: number; title: string; description: string; assignee: string; relatedPeople?: string[]; dueDate: string; status: TaskStatus; }
export interface AttendanceEntry { type: 'Check In' | 'Check Out'; time: Date; location?: string; }
export interface Notification { id: number; message: string; time: string; read: boolean; }


// --- Initial Data (Việt hóa) ---
const initialUsers: User[] = [
    { id: 1, name: 'Quản trị viên', email: 'admin@lavis.com', role: 'Quản trị viên', avatar: 'https://picsum.photos/id/1005/100/100' },
    { id: 2, name: 'Nhân viên A', email: 'nhanvien.a@lavis.com', role: 'Nhân viên', avatar: 'https://picsum.photos/id/1011/100/100' },
];
const initialLeadsData: Lead[] = [
  { id: 1, name: 'John Doe', company: 'Innovate Inc.', email: 'john.d@innovate.com', phone: '555-1234', status: 'Mới' },
  { id: 2, name: 'Jane Smith', company: 'Solutions Co.', email: 'jane.s@solutions.co', phone: '555-5678', status: 'Đang chăm sóc' },
  { id: 3, name: 'Peter Jones', company: 'MegaCorp', email: 'peter.j@megacorp.com', phone: '555-8765', status: 'Tiềm năng' },
];
const initialDealsData: Deal[] = [
    { id: 1, name: 'Thiết kế lại Website', company: 'Innovate Inc.', value: 25000, stage: 'Trình bày', closeDate: '2024-08-15' },
    { id: 2, name: 'Tư vấn CRM', company: 'Solutions Co.', value: 18000, stage: 'Thương lượng', closeDate: '2024-07-30' },
    { id: 3, name: 'Hợp đồng bảo trì', company: 'MegaCorp', value: 50000, stage: 'Thắng', closeDate: '2024-07-01' },
];
const initialContactsData: Contact[] = [
    { id: 1, name: 'John Doe', company: 'Innovate Inc.', email: 'john.d@innovate.com', phone: '555-1234', role: 'CTO' },
    { id: 2, name: 'Jane Smith', company: 'Solutions Co.', email: 'jane.s@solutions.co', phone: '555-5678', role: 'Project Manager' },
    { id: 3, name: 'Peter Jones', company: 'MegaCorp', email: 'peter.j@megacorp.com', phone: '555-8765', role: 'CEO' },
];
const initialTasksData: Task[] = [
    { id: 1, title: 'Chuẩn bị báo giá cho Innovate Inc.', description: 'Làm báo giá chi tiết cho dự án thiết kế lại website.', assignee: 'Nhân viên A', dueDate: new Date().toISOString().split('T')[0], status: 'Đang làm' },
    { id: 2, title: 'Gọi điện cho Jane Smith', description: 'Follow-up về buổi trình bày giải pháp CRM.', assignee: 'Nhân viên A', dueDate: '2024-07-28', status: 'Cần làm' },
    { id: 3, title: 'Hoàn thành hợp đồng MegaCorp', description: 'Gửi hợp đồng bảo trì cho Peter Jones.', assignee: 'Quản trị viên', dueDate: '2024-06-30', status: 'Hoàn thành' },
];
const initialNotifications: Notification[] = [
    { id: 1, message: 'Khách hàng mới "John Doe" đã được thêm.', time: '2 giờ trước', read: false },
    { id: 2, message: 'Cơ hội "Tư vấn CRM" đã chuyển sang giai đoạn Thương lượng.', time: '1 ngày trước', read: true },
    { id: 3, message: 'Bạn có một công việc mới: "Gọi điện cho Jane Smith".', time: '1 ngày trước', read: true },
];

const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [theme, rawSetTheme] = useState<Theme>(() => {
        const savedTheme = localStorage.getItem('theme') as Theme | null;
        return savedTheme || 'light';
    });

    const setTheme = (newTheme: Theme) => {
        rawSetTheme(newTheme);
        localStorage.setItem('theme', newTheme);
    };

    useEffect(() => {
        const root = window.document.documentElement;
        const isDark = theme === 'dark' || (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
        root.classList.toggle('dark', isDark);
    }, [theme]);
    
    return (
        <ThemeContext.Provider value={{ theme, setTheme }}>
            {children}
        </ThemeContext.Provider>
    );
};

const AuthGate: React.FC = () => {
    const [isAuthenticated, setIsAuthenticated] = useState(() => !!localStorage.getItem('isAuthenticated'));
    const [users, setUsers] = useState<User[]>(initialUsers);
    const [currentUser, setCurrentUser] = useState<User | null>(() => {
        const storedUserId = localStorage.getItem('userId');
        if (storedUserId) {
            return initialUsers.find(u => u.id === parseInt(storedUserId)) || null;
        }
        return null;
    });

    const [leads, setLeads] = useState<Lead[]>(initialLeadsData);
    const [deals, setDeals] = useState<Deal[]>(initialDealsData);
    const [contacts, setContacts] = useState<Contact[]>(initialContactsData);
    const [tasks, setTasks] = useState<Task[]>(initialTasksData);
    const [notifications, setNotifications] = useState<Notification[]>(initialNotifications);
    const [attendanceLog, setAttendanceLog] = useState<AttendanceEntry[]>([]);
    const [isCheckedIn, setIsCheckedIn] = useState(false);

    const handleLogin = (email: string, pass: string): boolean => {
        const user = users.find(u => u.email === email);
        // This is a dummy authentication. In a real app, you'd verify the password against a backend.
        if (user) {
            setCurrentUser(user);
            setIsAuthenticated(true);
            localStorage.setItem('isAuthenticated', 'true');
            localStorage.setItem('userId', user.id.toString());
            return true;
        }
        return false;
    };
    
    const handleLogout = () => {
        localStorage.removeItem('isAuthenticated');
        localStorage.removeItem('userId');
        setIsAuthenticated(false);
        setCurrentUser(null);
    };

    // --- Handlers ---
    const handleCheckInToggle = (location?: string) => {
        const newEntry: AttendanceEntry = {
            type: isCheckedIn ? 'Check Out' : 'Check In',
            time: new Date(),
            location: isCheckedIn ? undefined : location,
        };
        setAttendanceLog(prev => [newEntry, ...prev]);
        setIsCheckedIn(!isCheckedIn);
        setNotifications(prev => [{
            id: Date.now(),
            message: `Bạn vừa ${newEntry.type} lúc ${newEntry.time.toLocaleTimeString()}.`,
            time: 'Vừa xong',
            read: false,
        }, ...prev]);
    };

    const handleAddLead = (lead: Omit<Lead, 'id'>) => {
        const newLead: Lead = { ...lead, id: Date.now() };
        setLeads(prev => [...prev, newLead]);
        setNotifications(prev => [{
            id: Date.now(),
            message: `Khách hàng mới "${lead.name}" đã được thêm.`,
            time: 'Vừa xong',
            read: false,
        }, ...prev]);
    };
    
    const handleImportLeads = (newLeads: Omit<Lead, 'id'>[]) => {
        const fullNewLeads = newLeads.map((lead, index) => ({...lead, id: Date.now() + index}));
        setLeads(prev => [...prev, ...fullNewLeads]);
        setNotifications(prev => [{
            id: Date.now(),
            message: `Đã nhập ${newLeads.length} khách hàng mới từ file CSV.`,
            time: 'Vừa xong',
            read: false,
        }, ...prev]);
    };

    const handleAddDeal = (deal: Omit<Deal, 'id'>) => {
        const newDeal: Deal = { ...deal, id: Date.now() };
        setDeals(prev => [...prev, newDeal]);
        setNotifications(prev => [{
            id: Date.now(),
            message: `Cơ hội mới "${deal.name}" đã được tạo.`,
            time: 'Vừa xong',
            read: false,
        }, ...prev]);
    };
    
    const handleUpdateDealStage = (dealId: number, newStage: DealStatus) => {
        setDeals(prev => prev.map(deal => deal.id === dealId ? {...deal, stage: newStage} : deal));
    };

    const handleAddContact = (contact: Omit<Contact, 'id'>) => {
        const newContact: Contact = { ...contact, id: Date.now() };
        setContacts(prev => [...prev, newContact]);
    };

    const handleAddTask = (task: Omit<Task, 'id' | 'status'>) => {
        const newTask: Task = { ...task, id: Date.now(), status: 'Cần làm' };
        setTasks(prev => [...prev, newTask]);
        setNotifications(prev => [{
            id: Date.now(),
            message: `Bạn có công việc mới: "${task.title}".`,
            time: 'Vừa xong',
            read: false,
        }, ...prev]);
    };
    
    const handleUpdateTaskStatus = (taskId: number, newStatus: TaskStatus) => {
        setTasks(prev => prev.map(task => task.id === taskId ? {...task, status: newStatus} : task));
    };
    
    const handleAddUser = (user: Omit<User, 'id' | 'avatar'>) => {
        const newUser: User = { ...user, id: Date.now(), avatar: `https://i.pravatar.cc/100?u=${Date.now()}` };
        setUsers(prev => [...prev, newUser]);
    };
    
    const handleUpdateCurrentUser = (data: { name: string; email: string; avatarFile?: File }) => {
        if (!currentUser) return;
        const avatarUrl = data.avatarFile ? URL.createObjectURL(data.avatarFile) : currentUser.avatar;
        const updatedUser = { ...currentUser, name: data.name, email: data.email, avatar: avatarUrl };
        setCurrentUser(updatedUser);
        setUsers(prev => prev.map(u => u.id === currentUser.id ? updatedUser : u));
    };
    
    const handleUpdateUserRole = (userId: number, role: 'Quản trị viên' | 'Nhân viên') => {
        setUsers(prev => prev.map(u => u.id === userId ? {...u, role} : u));
    };

    if (!isAuthenticated || !currentUser) {
        return <Login onLogin={handleLogin} />;
    }

    return (
        <HashRouter>
            <div className="flex h-screen bg-background text-foreground font-sans">
                <Sidebar currentUser={currentUser} onLogout={handleLogout} />
                <div className="flex-1 flex flex-col overflow-hidden">
                    <Header
                        currentUser={currentUser}
                        notifications={notifications}
                        setNotifications={setNotifications}
                    />
                    <main className="flex-1 overflow-x-hidden overflow-y-auto bg-background p-6">
                        <Routes>
                             <Route path="/" element={<Navigate to="/dashboard" replace />} />
                            <Route path="/dashboard" element={<Dashboard leads={leads} deals={deals} tasks={tasks} isCheckedIn={isCheckedIn} onCheckInToggle={handleCheckInToggle} attendanceLog={attendanceLog} />} />
                            <Route path="/attendance" element={<Attendance isCheckedIn={isCheckedIn} onToggleCheckIn={handleCheckInToggle} log={attendanceLog} />} />
                            <Route path="/leads" element={<Leads leads={leads} onAddLead={handleAddLead} onImportLeads={handleImportLeads} />} />
                            <Route path="/deals" element={<Deals deals={deals} onAddDeal={handleAddDeal} onUpdateDealStage={handleUpdateDealStage} />} />
                            <Route path="/contacts" element={<Contacts contacts={contacts} onAddContact={handleAddContact} />} />
                            <Route path="/tasks-projects" element={<TasksAndProjects tasks={tasks} users={users} onAddTask={handleAddTask} onUpdateTaskStatus={handleUpdateTaskStatus} />} />
                            <Route path="/reports" element={<Reports deals={deals} tasks={tasks} leads={leads} />} />
                            <Route path="/settings" element={<Settings users={users} onAddUser={handleAddUser} currentUser={currentUser} onUpdateCurrentUser={handleUpdateCurrentUser} onUpdateUserRole={handleUpdateUserRole} />} />
                        </Routes>
                    </main>
                </div>
            </div>
        </HashRouter>
    );
};

const App: React.FC = () => {
    return (
        <ThemeProvider>
            <AuthGate />
        </ThemeProvider>
    );
};

export default App;
