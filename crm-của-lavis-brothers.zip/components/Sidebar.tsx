
import React from 'react';
import { NavLink } from 'react-router-dom';
import { DashboardIcon, AttendanceIcon, LeadsIcon, DealsIcon, ContactsIcon, TasksIcon, ReportsIcon, SettingsIcon, LogOutIcon } from './icons';
import { User } from '../App';

const navItems = [
  { to: '/dashboard', label: 'Bảng điều khiển', icon: DashboardIcon },
  { to: '/attendance', label: 'Chấm công', icon: AttendanceIcon },
  { to: '/leads', label: 'Khách hàng', icon: LeadsIcon },
  { to: '/deals', label: 'Cơ hội', icon: DealsIcon },
  { to: '/contacts', label: 'Danh bạ', icon: ContactsIcon },
  { to: '/tasks-projects', label: 'Công việc & Dự án', icon: TasksIcon },
  { to: '/reports', label: 'Báo cáo', icon: ReportsIcon },
  { to: '/settings', label: 'Cài đặt', icon: SettingsIcon },
];

interface SidebarProps {
  currentUser: User;
  onLogout: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ currentUser, onLogout }) => {
  const NavItem: React.FC<{ to: string; label: string; icon: React.FC<{ className?: string }> }> = ({ to, label, icon: Icon }) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center px-4 py-3 text-gray-200 hover:bg-white/20 transition-colors duration-200 rounded-md ${
          isActive ? 'bg-white/30 backdrop-blur-lg text-white font-semibold' : 'hover:text-white'
        }`
      }
    >
      <Icon className="h-5 w-5 mr-3" />
      <span>{label}</span>
    </NavLink>
  );

  return (
    <div className="flex flex-col w-64 text-white h-full animate-bg-pan">
      <div className="flex items-center justify-center h-20 border-b border-white/20 px-4">
          <h1 className="text-xl font-bold text-white tracking-wider">Lavis Brothers CRM</h1>
      </div>
      <nav className="flex-1 px-4 py-4 space-y-2">
        {navItems.map(item => (
          <NavItem key={item.to} {...item} />
        ))}
      </nav>
      <div className="px-4 py-4 border-t border-white/20">
        <div className="flex items-center mb-4">
            <img className="h-10 w-10 rounded-full object-cover" src={currentUser.avatar} alt="User Avatar" />
            <div className="ml-3">
                <p className="text-sm font-semibold text-white">{currentUser.name}</p>
                <p className="text-xs text-gray-300">{currentUser.email}</p>
            </div>
        </div>
        <button
          onClick={onLogout}
          className="flex items-center w-full px-4 py-3 text-gray-200 hover:bg-white/20 transition-colors duration-200 rounded-md hover:text-white"
        >
          <LogOutIcon className="h-5 w-5 mr-3" />
          <span>Đăng xuất</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
