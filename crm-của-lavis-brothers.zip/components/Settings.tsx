import React, { useState, useEffect } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Modal from './ui/Modal';
import { useTheme } from '../App';
import { SunIcon, MoonIcon, LaptopIcon, UserPlusIcon, PencilIcon, TrashIcon } from './icons';
import { User } from '../App';

interface SettingsProps {
    users: User[];
    onAddUser: (user: Omit<User, 'id' | 'avatar'>) => void;
    currentUser: User;
    onUpdateCurrentUser: (data: { name: string; email: string; avatarFile?: File }) => void;
    onUpdateUserRole: (userId: number, role: 'Quản trị viên' | 'Nhân viên') => void;
}

const formInputStyle = "mt-1 block w-full bg-input border border-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-ring text-foreground placeholder:text-muted-foreground transition-colors duration-200";

const Settings: React.FC<SettingsProps> = ({ users, onAddUser, currentUser, onUpdateCurrentUser, onUpdateUserRole }) => {
  const { theme, setTheme } = useTheme();
  
  // State for modals
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const [isRoleModalOpen, setIsRoleModalOpen] = useState(false);
  
  // State for forms
  const [newUser, setNewUser] = useState<Omit<User, 'id' | 'avatar'>>({ name: '', email: '', role: 'Nhân viên' });
  const [profileData, setProfileData] = useState({ name: currentUser.name, email: currentUser.email, avatarFile: undefined as File | undefined, avatarPreview: currentUser.avatar });
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [newRole, setNewRole] = useState<'Quản trị viên' | 'Nhân viên'>('Nhân viên');

  useEffect(() => {
    setProfileData({ name: currentUser.name, email: currentUser.email, avatarFile: undefined, avatarPreview: currentUser.avatar });
  }, [currentUser]);

  const handleProfileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setProfileData(prev => ({
        ...prev,
        avatarFile: file,
        avatarPreview: URL.createObjectURL(file)
      }));
    }
  };
  
  const handleProfileSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateCurrentUser({ name: profileData.name, email: profileData.email, avatarFile: profileData.avatarFile });
    setIsProfileModalOpen(false);
  };

  const handleAddUserSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddUser(newUser);
    setIsAddUserModalOpen(false);
    setNewUser({ name: '', email: '', role: 'Nhân viên' });
  };
  
  const handleRoleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(editingUser) {
        onUpdateUserRole(editingUser.id, newRole);
    }
    setIsRoleModalOpen(false);
    setEditingUser(null);
  }
  
  const ThemeButton = ({ value, icon: Icon, label }: { value: 'light' | 'dark' | 'system', icon: React.FC<any>, label: string }) => (
    <button
      onClick={() => setTheme(value)}
      className={`flex flex-col items-center justify-center w-24 h-24 rounded-lg border-2 transition-colors ${
        theme === value ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/50' : 'border-border hover:border-blue-400'
      }`}
    >
      <Icon className="w-8 h-8 mb-2" />
      <span className="text-sm font-medium">{label}</span>
    </button>
  );

  return (
    <div className="space-y-8">
      <Card>
        <h2 className="text-xl font-semibold text-foreground mb-4">Thông tin cá nhân</h2>
        <div className="flex items-center gap-6">
            <img src={currentUser.avatar} alt="Avatar" className="w-24 h-24 rounded-full object-cover" />
            <div>
                <h3 className="text-2xl font-bold">{currentUser.name}</h3>
                <p className="text-muted-foreground">{currentUser.email}</p>
                <p className="text-sm text-foreground mt-1 px-2 py-0.5 bg-secondary rounded-full inline-block">{currentUser.role}</p>
            </div>
            <Button variant="secondary" onClick={() => setIsProfileModalOpen(true)} className="ml-auto">Chỉnh sửa hồ sơ</Button>
        </div>
      </Card>

      <Card>
        <h2 className="text-xl font-semibold text-foreground mb-4">Giao diện</h2>
        <div className="flex flex-wrap gap-4">
            <ThemeButton value="light" icon={SunIcon} label="Sáng" />
            <ThemeButton value="dark" icon={MoonIcon} label="Tối" />
            <ThemeButton value="system" icon={LaptopIcon} label="Hệ thống" />
        </div>
      </Card>
      
      {currentUser.role === 'Quản trị viên' && (
        <Card>
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-semibold text-foreground">Quản lý người dùng</h2>
                <Button onClick={() => setIsAddUserModalOpen(true)} className="flex items-center gap-2">
                    <UserPlusIcon className="w-5 h-5" />
                    <span>Thêm người dùng</span>
                </Button>
            </div>
            <div className="overflow-x-auto">
            <table className="w-full text-left">
                <thead>
                <tr className="bg-secondary border-b border-border">
                    <th className="p-3 text-sm font-semibold text-muted-foreground">Họ tên</th>
                    <th className="p-3 text-sm font-semibold text-muted-foreground">Email</th>
                    <th className="p-3 text-sm font-semibold text-muted-foreground">Vai trò</th>
                    <th className="p-3 text-sm font-semibold text-muted-foreground">Hành động</th>
                </tr>
                </thead>
                <tbody>
                {users.map((user) => (
                    <tr key={user.id} className="border-b border-border hover:bg-muted">
                    <td className="p-3 flex items-center gap-3">
                        <img src={user.avatar} alt={user.name} className="w-8 h-8 rounded-full" />
                        <span className="font-medium text-foreground">{user.name}</span>
                    </td>
                    <td className="p-3 text-muted-foreground">{user.email}</td>
                    <td className="p-3">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${user.role === 'Quản trị viên' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'}`}>
                            {user.role}
                        </span>
                    </td>
                    <td className="p-3">
                        <div className="flex items-center gap-2">
                            <Button variant="ghost" size="sm" onClick={() => { setEditingUser(user); setNewRole(user.role); setIsRoleModalOpen(true); }}><PencilIcon className="w-4 h-4" /></Button>
                            <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600"><TrashIcon className="w-4 h-4" /></Button>
                        </div>
                    </td>
                    </tr>
                ))}
                </tbody>
            </table>
            </div>
        </Card>
      )}

      {/* Modal chỉnh sửa hồ sơ cá nhân */}
      <Modal isOpen={isProfileModalOpen} onClose={() => setIsProfileModalOpen(false)} title="Chỉnh sửa hồ sơ">
        <form onSubmit={handleProfileSubmit} className="space-y-4">
            <div className="flex flex-col items-center space-y-4">
                <img src={profileData.avatarPreview} alt="Xem trước avatar" className="w-32 h-32 rounded-full object-cover"/>
                <input type="file" id="avatar-upload" className="hidden" accept="image/*" onChange={handleAvatarChange} />
                <Button type="button" variant="secondary" onClick={() => document.getElementById('avatar-upload')?.click()}>Đổi ảnh đại diện</Button>
            </div>
             <div>
                <label htmlFor="name" className="block text-sm font-medium text-muted-foreground">Họ và tên</label>
                <input type="text" name="name" id="name" value={profileData.name} onChange={handleProfileInputChange} className={formInputStyle} required />
            </div>
            <div>
                <label htmlFor="email" className="block text-sm font-medium text-muted-foreground">Email</label>
                <input type="email" name="email" id="email" value={profileData.email} onChange={handleProfileInputChange} className={formInputStyle} required />
            </div>
            <div className="flex justify-end pt-4 space-x-2">
                <Button type="button" variant="secondary" onClick={() => setIsProfileModalOpen(false)}>Hủy</Button>
                <Button type="submit">Lưu thay đổi</Button>
            </div>
        </form>
      </Modal>

      {/* Modal thêm người dùng mới */}
      <Modal isOpen={isAddUserModalOpen} onClose={() => setIsAddUserModalOpen(false)} title="Thêm người dùng mới">
        <form onSubmit={handleAddUserSubmit} className="space-y-4">
          <div>
            <label htmlFor="add-name" className="block text-sm font-medium text-muted-foreground">Họ và tên</label>
            <input type="text" name="name" id="add-name" value={newUser.name} onChange={(e) => setNewUser({...newUser, name: e.target.value})} className={formInputStyle} required />
          </div>
          <div>
            <label htmlFor="add-email" className="block text-sm font-medium text-muted-foreground">Email</label>
            <input type="email" name="email" id="add-email" value={newUser.email} onChange={(e) => setNewUser({...newUser, email: e.target.value})} className={formInputStyle} required />
          </div>
           <div>
            <label htmlFor="add-password" className="block text-sm font-medium text-muted-foreground">Mật khẩu</label>
            <input type="password" name="password" id="add-password" className={formInputStyle} required />
          </div>
          <div>
             <label htmlFor="add-role" className="block text-sm font-medium text-muted-foreground">Vai trò</label>
             <select name="role" id="add-role" value={newUser.role} onChange={(e) => setNewUser({...newUser, role: e.target.value as any})} className={formInputStyle}>
                <option>Nhân viên</option>
                <option>Quản trị viên</option>
             </select>
          </div>
          <div className="flex justify-end pt-4 space-x-2">
             <Button type="button" variant="secondary" onClick={() => setIsAddUserModalOpen(false)}>Hủy</Button>
             <Button type="submit">Tạo người dùng</Button>
          </div>
        </form>
      </Modal>

       {/* Modal chỉnh sửa vai trò */}
      <Modal isOpen={isRoleModalOpen} onClose={() => setIsRoleModalOpen(false)} title={`Chỉnh sửa vai trò cho ${editingUser?.name}`}>
        <form onSubmit={handleRoleSubmit} className="space-y-4">
            <div>
                <p className="text-muted-foreground">Chọn vai trò mới cho người dùng <span className="font-bold text-foreground">{editingUser?.name}</span>.</p>
            </div>
            <div>
             <label htmlFor="edit-role" className="block text-sm font-medium text-muted-foreground">Vai trò</label>
             <select name="role" id="edit-role" value={newRole} onChange={(e) => setNewRole(e.target.value as any)} className={formInputStyle}>
                <option>Nhân viên</option>
                <option>Quản trị viên</option>
             </select>
            </div>
            <div className="flex justify-end pt-4 space-x-2">
                <Button type="button" variant="secondary" onClick={() => setIsRoleModalOpen(false)}>Hủy</Button>
                <Button type="submit">Cập nhật vai trò</Button>
            </div>
        </form>
      </Modal>
    </div>
  );
};

export default Settings;