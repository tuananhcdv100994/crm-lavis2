import React, { useState, useRef } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Modal from './ui/Modal';
import { Lead, LeadStatus } from '../App';

interface LeadsProps {
  leads: Lead[];
  onAddLead: (lead: Omit<Lead, 'id'>) => void;
  onImportLeads: (leads: Omit<Lead, 'id'>[]) => void;
}

const LEAD_STATUSES: LeadStatus[] = ['Mới', 'Đang chăm sóc', 'Tiềm năng', 'Không tiềm năng'];
const formInputStyle = "mt-1 block w-full bg-input border border-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-ring text-foreground placeholder:text-muted-foreground transition-colors duration-200";

const Leads: React.FC<LeadsProps> = ({ leads, onAddLead, onImportLeads }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newLead, setNewLead] = useState<Omit<Lead, 'id'>>({ name: '', company: '', email: '', phone: '', status: 'Mới' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewLead(prev => ({ ...prev, [name]: value as any }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddLead(newLead);
    setIsModalOpen(false);
    setNewLead({ name: '', company: '', email: '', phone: '', status: 'Mới' });
  };
    
  const getStatusClass = (status: LeadStatus) => {
    switch (status) {
      case 'Mới': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'Đang chăm sóc': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
      case 'Tiềm năng': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'Không tiềm năng': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  const handleExportCSV = () => {
    const headers = ['name', 'company', 'email', 'phone', 'status'];
    const csvContent = [
      headers.join(','),
      ...leads.map(lead => headers.map(header => `"${lead[header as keyof Lead]}"`).join(','))
    ].join('\n');
    
    const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', 'danh_sach_khach_hang.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const rows = text.split('\n').slice(1); // Bỏ qua header
      const importedLeads: Omit<Lead, 'id'>[] = rows
        .map(row => {
          const [name, company, email, phone, status] = row.split(',').map(field => field.trim().replace(/"/g, ''));
          if (name && company && email && status && LEAD_STATUSES.includes(status as LeadStatus)) {
            return { name, company, email, phone, status: status as Lead['status'] };
          }
          return null;
        })
        .filter((lead): lead is Omit<Lead, 'id'> => lead !== null);
      onImportLeads(importedLeads);
    };
    reader.readAsText(file);
    e.target.value = ''; // Reset file input
  };

  return (
    <>
      <Card>
        <div className="flex justify-between items-center mb-4 flex-wrap gap-2">
          <h2 className="text-xl font-semibold text-foreground">Tất cả khách hàng</h2>
          <div className="flex gap-2">
            <input type="file" ref={fileInputRef} onChange={handleFileImport} className="hidden" accept=".csv" />
            <Button onClick={handleImportClick} variant="secondary">Nhập CSV</Button>
            <Button onClick={handleExportCSV} variant="secondary">Xuất CSV</Button>
            <Button onClick={() => setIsModalOpen(true)}>Thêm khách hàng</Button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-secondary border-b border-border">
                <th className="p-3 text-sm font-semibold text-muted-foreground">Tên</th>
                <th className="p-3 text-sm font-semibold text-muted-foreground">Công ty</th>
                <th className="p-3 text-sm font-semibold text-muted-foreground">Email</th>
                <th className="p-3 text-sm font-semibold text-muted-foreground">Điện thoại</th>
                <th className="p-3 text-sm font-semibold text-muted-foreground">Trạng thái</th>
              </tr>
            </thead>
            <tbody>
              {leads.map((lead) => (
                <tr key={lead.id} className="border-b border-border hover:bg-muted">
                  <td className="p-3 text-foreground">{lead.name}</td>
                  <td className="p-3 text-muted-foreground">{lead.company}</td>
                  <td className="p-3 text-muted-foreground">{lead.email}</td>
                  <td className="p-3 text-muted-foreground">{lead.phone}</td>
                  <td className="p-3">
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(lead.status)}`}>
                      {lead.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Thêm khách hàng mới">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-muted-foreground">Họ và tên</label>
            <input type="text" name="name" id="name" value={newLead.name} onChange={handleInputChange} className={formInputStyle} required />
          </div>
          <div>
            <label htmlFor="company" className="block text-sm font-medium text-muted-foreground">Công ty</label>
            <input type="text" name="company" id="company" value={newLead.company} onChange={handleInputChange} className={formInputStyle} required />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-muted-foreground">Email</label>
            <input type="email" name="email" id="email" value={newLead.email} onChange={handleInputChange} className={formInputStyle} required />
          </div>
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-muted-foreground">Điện thoại</label>
            <input type="tel" name="phone" id="phone" value={newLead.phone} onChange={handleInputChange} className={formInputStyle} />
          </div>
          <div>
             <label htmlFor="status" className="block text-sm font-medium text-muted-foreground">Trạng thái</label>
             <select name="status" id="status" value={newLead.status} onChange={handleInputChange} className={formInputStyle}>
                {LEAD_STATUSES.map(s => <option key={s}>{s}</option>)}
             </select>
          </div>
          <div className="flex justify-end pt-4">
            <Button type="submit">Tạo khách hàng</Button>
          </div>
        </form>
      </Modal>
    </>
  );
};

export default Leads;