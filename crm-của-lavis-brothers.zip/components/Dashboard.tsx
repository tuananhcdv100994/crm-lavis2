import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Card from './ui/Card';
import Button from './ui/Button';
import { Lead, Deal, Task, AttendanceEntry } from '../App';
import { BellIcon } from './icons';

interface DashboardProps {
  leads: Lead[];
  deals: Deal[];
  tasks: Task[];
  isCheckedIn: boolean;
  onCheckInToggle: () => void;
  attendanceLog: AttendanceEntry[];
}

const StatCard: React.FC<{ title: string; value: string; description: string }> = ({ title, value, description }) => (
    <Card>
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        <p className="mt-1 text-3xl font-semibold text-foreground">{value}</p>
        <p className="text-sm text-muted-foreground mt-1">{description}</p>
    </Card>
);

const Dashboard: React.FC<DashboardProps> = ({ leads, deals, tasks, isCheckedIn, onCheckInToggle, attendanceLog }) => {
  const tickColor = 'hsl(var(--muted-foreground))';
  const gridColor = 'hsl(var(--border))';

  const dealsInProgress = deals.filter(deal => deal.stage !== 'Thắng' && deal.stage !== 'Thua').length;
  const tasksDueToday = tasks.filter(task => {
    const today = new Date().toISOString().split('T')[0];
    return task.dueDate === today && task.status !== 'Hoàn thành';
  }).length;
  
  const dealsByStageData = deals.reduce((acc, deal) => {
      const stage = acc.find(item => item.name === deal.stage);
      if (stage) {
          stage.value += 1;
      } else {
          acc.push({ name: deal.stage, value: 1 });
      }
      return acc;
  }, [] as { name: string; value: number }[]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Tổng số khách hàng" value={leads.length.toString()} description="Từ trước đến nay" />
        <StatCard title="Cơ hội đang theo dõi" value={dealsInProgress.toString()} description="Đang trong quy trình" />
        <StatCard title="Việc cần làm hôm nay" value={tasksDueToday.toString()} description={tasksDueToday > 0 ? "Cần hành động" : "Không có việc gấp"} />
        <Card>
            <h3 className="text-sm font-medium text-muted-foreground">Chấm công</h3>
            <p className={`mt-1 text-lg font-semibold ${isCheckedIn ? 'text-green-600' : 'text-yellow-600'}`}>
              {isCheckedIn ? 'Bạn đã Check In' : 'Bạn đã Check Out'}
            </p>
            <Button onClick={() => onCheckInToggle()} className="w-full mt-2">
              {isCheckedIn ? 'Check Out' : 'Check In'}
            </Button>
        </Card>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
              <h3 className="font-semibold text-foreground">Cơ hội theo giai đoạn</h3>
              <div className="h-80 mt-4">
                  <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={dealsByStageData} layout="vertical" margin={{ top: 5, right: 20, left: 100, bottom: 5 }}>
                           <CartesianGrid strokeDasharray="3 3" stroke={gridColor}/>
                           <XAxis type="number" stroke={tickColor} />
                           <YAxis type="category" dataKey="name" width={100} interval={0} stroke={tickColor} tick={{ fill: tickColor }} />
                           <Tooltip
                              contentStyle={{ 
                                backgroundColor: 'hsl(var(--card))', 
                                border: `1px solid ${gridColor}`,
                                color: 'hsl(var(--card-foreground))'
                              }} 
                           />
                           <Legend wrapperStyle={{ color: tickColor }}/>
                           <Bar dataKey="value" fill="#1d4ed8" name="Số lượng cơ hội"/>
                      </BarChart>
                  </ResponsiveContainer>
              </div>
          </Card>
          <Card>
             <h3 className="font-semibold text-foreground">Hoạt động gần đây</h3>
             <div className="mt-4 space-y-4 overflow-y-auto h-80 pr-2">
                {attendanceLog.length > 0 ? attendanceLog.slice(0, 5).map((log, index) => (
                    <div key={index} className="flex items-start">
                        <div className="flex-shrink-0">
                            <span className={`h-8 w-8 rounded-full flex items-center justify-center ${log.type === 'Check In' ? 'bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300' : 'bg-yellow-100 dark:bg-yellow-900 text-yellow-700 dark:text-yellow-300'}`}>
                                <BellIcon className="h-5 w-5"/>
                            </span>
                        </div>
                        <div className="ml-3">
                            <p className="text-sm font-medium text-foreground">{log.type}</p>
                            <p className="text-sm text-muted-foreground">{log.time.toLocaleTimeString()}</p>
                            {log.location && <p className="text-xs text-muted-foreground">Vị trí: {log.location}</p>}
                        </div>
                    </div>
                )) : (
                    <p className="text-sm text-muted-foreground">Không có hoạt động gần đây.</p>
                )}
             </div>
          </Card>
      </div>
    </div>
  );
};

export default Dashboard;
