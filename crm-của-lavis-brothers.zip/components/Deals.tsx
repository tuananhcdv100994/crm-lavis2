import React, { useState } from 'react';
import Button from './ui/Button';
import Modal from './ui/Modal';
import { Deal, DealStatus } from '../App';

interface DealsProps {
  deals: Deal[];
  onAddDeal: (deal: Omit<Deal, 'id'>) => void;
  onUpdateDealStage: (dealId: number, newStage: DealStatus) => void;
}

const DEAL_STAGES: DealStatus[] = ['Khám phá', 'Trình bày', 'Thương lượng', 'Thắng', 'Thua'];

const STAGE_COLORS: Record<DealStatus, string> = {
    'Khám phá': 'border-purple-500',
    'Trình bày': 'border-blue-500',
    'Thương lượng': 'border-yellow-500',
    'Thắng': 'border-green-500',
    'Thua': 'border-red-500',
};

const formInputStyle = "mt-1 block w-full bg-input border border-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-ring text-foreground placeholder:text-muted-foreground transition-colors duration-200";

const DealCard: React.FC<{ deal: Deal }> = ({ deal }) => {
    return (
        <div 
            className={`p-4 bg-card text-card-foreground rounded-lg shadow-sm mb-4 border-l-4 ${STAGE_COLORS[deal.stage]} transition-transform duration-200 hover:-translate-y-1`}
            draggable="true"
            onDragStart={(e) => {
                e.dataTransfer.setData('dealId', deal.id.toString());
            }}
        >
            <h4 className="font-semibold text-foreground">{deal.name}</h4>
            <p className="text-sm text-muted-foreground mt-1">{deal.company}</p>
            <p className="text-sm font-bold text-foreground mt-2">${deal.value.toLocaleString()}</p>
            <p className="text-xs text-muted-foreground mt-2">Ngày chốt: {deal.closeDate}</p>
        </div>
    );
}


const Deals: React.FC<DealsProps> = ({ deals, onAddDeal, onUpdateDealStage }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newDeal, setNewDeal] = useState<Omit<Deal, 'id'>>({
      name: '', company: '', value: 0, stage: 'Khám phá', closeDate: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewDeal(prev => ({ ...prev, [name]: name === 'value' ? parseFloat(value) : value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddDeal(newDeal);
    setIsModalOpen(false);
    setNewDeal({ name: '', company: '', value: 0, stage: 'Khám phá', closeDate: '' });
  };
  
  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
  }

  const handleDrop = (e: React.DragEvent<HTMLDivElement>, newStage: DealStatus) => {
      e.preventDefault();
      const dealId = e.dataTransfer.getData('dealId');
      if (dealId) {
          onUpdateDealStage(Number(dealId), newStage);
      }
  }

  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-foreground">Quy trình bán hàng</h2>
        <Button onClick={() => setIsModalOpen(true)}>Thêm cơ hội mới</Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5">
        {DEAL_STAGES.map(stage => (
          <div key={stage}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, stage)}
          >
            <h3 className={`font-semibold text-lg text-foreground mb-4 px-2 pb-2 border-b-2 ${STAGE_COLORS[stage]}`}>{stage}</h3>
            <div className="bg-muted p-3 rounded-lg min-h-[600px]">
              {deals.filter(deal => deal.stage === stage).map(deal => (
                <DealCard key={deal.id} deal={deal} />
              ))}
            </div>
          </div>
        ))}
      </div>

      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Thêm cơ hội mới">
        <form onSubmit={handleSubmit} className="space-y-4">
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-muted-foreground">Tên cơ hội</label>
                <input type="text" name="name" id="name" value={newDeal.name} onChange={handleInputChange} className={formInputStyle} required />
            </div>
            <div>
                <label htmlFor="company" className="block text-sm font-medium text-muted-foreground">Công ty</label>
                <input type="text" name="company" id="company" value={newDeal.company} onChange={handleInputChange} className={formInputStyle} required />
            </div>
            <div>
                <label htmlFor="value" className="block text-sm font-medium text-muted-foreground">Giá trị ($)</label>
                <input type="number" name="value" id="value" value={newDeal.value} onChange={handleInputChange} className={formInputStyle} required />
            </div>
            <div>
                <label htmlFor="stage" className="block text-sm font-medium text-muted-foreground">Giai đoạn</label>
                <select name="stage" id="stage" value={newDeal.stage} onChange={handleInputChange} className={formInputStyle}>
                    {DEAL_STAGES.map(s => <option key={s}>{s}</option>)}
                </select>
            </div>
            <div>
                <label htmlFor="closeDate" className="block text-sm font-medium text-muted-foreground">Ngày dự kiến chốt</label>
                <input type="date" name="closeDate" id="closeDate" value={newDeal.closeDate} onChange={handleInputChange} className={formInputStyle} required />
            </div>
            <div className="flex justify-end pt-4">
              <Button type="submit">Tạo cơ hội</Button>
            </div>
        </form>
      </Modal>
    </>
  );
};

export default Deals;