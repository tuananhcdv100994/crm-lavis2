import React, { useState } from 'react';
import Button from './ui/Button';
import Modal from './ui/Modal';
import Card from './ui/Card';
import { Task, TaskStatus, User } from '../App';

interface TasksAndProjectsProps {
  tasks: Task[];
  users: User[];
  onAddTask: (task: Omit<Task, 'id' | 'status'>) => void;
  onUpdateTaskStatus: (taskId: number, status: TaskStatus) => void;
}

const TASK_STATUSES: TaskStatus[] = ['Cần làm', 'Đang làm', 'Chờ duyệt', 'Hoàn thành'];

const getStatusClass = (status: TaskStatus) => {
    switch (status) {
        case 'Cần làm': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300';
        case 'Đang làm': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
        case 'Chờ duyệt': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300';
        case 'Hoàn thành': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
        default: return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
};

const formInputStyle = "mt-1 block w-full bg-input border border-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-ring text-foreground placeholder:text-muted-foreground transition-colors duration-200";

const TasksAndProjects: React.FC<TasksAndProjectsProps> = ({ tasks, users, onAddTask, onUpdateTaskStatus }) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  
  const [newTask, setNewTask] = useState<Omit<Task, 'id' | 'status'>>({
      title: '', description: '', assignee: users[0]?.name || '', dueDate: '', relatedPeople: []
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setNewTask(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.title || !newTask.dueDate) return; // Basic validation
    onAddTask(newTask);
    setIsAddModalOpen(false);
    setNewTask({ title: '', description: '', assignee: users[0]?.name || '', dueDate: '', relatedPeople: [] });
  };
  
  return (
    <>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold text-foreground">Danh sách Công việc</h2>
        <Button onClick={() => setIsAddModalOpen(true)}>Thêm công việc mới</Button>
      </div>

      <Card>
        <div className="overflow-x-auto">
            <table className="w-full text-left">
                <thead>
                    <tr className="bg-secondary border-b border-border">
                        <th className="p-3 text-sm font-semibold text-muted-foreground">Tiêu đề</th>
                        <th className="p-3 text-sm font-semibold text-muted-foreground">Giao cho</th>
                        <th className="p-3 text-sm font-semibold text-muted-foreground">Hạn chót</th>
                        <th className="p-3 text-sm font-semibold text-muted-foreground w-48">Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    {tasks.map((task) => (
                        <tr 
                            key={task.id} 
                            className="border-b border-border hover:bg-muted cursor-pointer"
                            onClick={() => setSelectedTask(task)}
                        >
                            <td className="p-3 font-medium text-foreground">{task.title}</td>
                            <td className="p-3 text-muted-foreground">{task.assignee}</td>
                            <td className="p-3 text-muted-foreground">{task.dueDate}</td>
                            <td className="p-3" onClick={(e) => e.stopPropagation()}>
                                <select 
                                    value={task.status} 
                                    onChange={(e) => onUpdateTaskStatus(task.id, e.target.value as TaskStatus)}
                                    className={`w-full rounded-md px-2 py-1 focus:outline-none focus:ring-1 focus:ring-ring border-none text-xs font-medium ${getStatusClass(task.status)}`}
                                >
                                    {TASK_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      </Card>

      {/* Modal Thêm công việc mới */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Thêm công việc mới">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="title" className="block text-sm font-medium text-muted-foreground">Tiêu đề công việc</label>
            <input type="text" name="title" id="title" value={newTask.title} onChange={handleInputChange} className={formInputStyle} required />
          </div>
          <div>
            <label htmlFor="description" className="block text-sm font-medium text-muted-foreground">Mô tả</label>
            <textarea name="description" id="description" value={newTask.description} onChange={handleInputChange} rows={3} className={formInputStyle}></textarea>
          </div>
          <div>
            <label htmlFor="assignee" className="block text-sm font-medium text-muted-foreground">Giao cho</label>
            <select name="assignee" id="assignee" value={newTask.assignee} onChange={handleInputChange} className={formInputStyle}>
                {users.map(user => <option key={user.id}>{user.name}</option>)}
            </select>
          </div>
           <div>
            <label htmlFor="relatedPeople" className="block text-sm font-medium text-muted-foreground">Người liên quan (phân cách bằng dấu phẩy)</label>
            <input type="text" name="relatedPeople" id="relatedPeople" value={(newTask.relatedPeople || []).join(', ')} onChange={(e) => setNewTask(prev => ({...prev, relatedPeople: e.target.value.split(',').map(s => s.trim())}))} className={formInputStyle} />
          </div>
          <div>
            <label htmlFor="dueDate" className="block text-sm font-medium text-muted-foreground">Hạn chót</label>
            <input type="date" name="dueDate" id="dueDate" value={newTask.dueDate} onChange={handleInputChange} className={formInputStyle} required />
          </div>
          <div className="flex justify-end pt-4 space-x-2">
            <Button type="button" variant="secondary" onClick={() => setIsAddModalOpen(false)}>Hủy</Button>
            <Button type="submit">Tạo công việc</Button>
          </div>
        </form>
      </Modal>
      
      {/* Modal Chi tiết công việc */}
      {selectedTask && (
        <Modal isOpen={!!selectedTask} onClose={() => setSelectedTask(null)} title="Chi tiết công việc">
            <div className="space-y-4">
                <div>
                    <h4 className="text-2xl font-bold text-foreground">{selectedTask.title}</h4>
                    <p className="text-sm text-muted-foreground">Hạn chót: {selectedTask.dueDate}</p>
                </div>
                <div className="text-base text-foreground max-w-none">
                    <p>{selectedTask.description || "Không có mô tả."}</p>
                </div>
                <div className="border-t border-border pt-4 mt-4 space-y-2 text-sm">
                    <p><strong className="text-muted-foreground">Người thực hiện:</strong> <span className="font-semibold text-foreground">{selectedTask.assignee}</span></p>
                    <p><strong className="text-muted-foreground">Trạng thái:</strong> <span className={`px-2 py-1 text-xs font-medium rounded-full ${getStatusClass(selectedTask.status)}`}>{selectedTask.status}</span></p>
                    {selectedTask.relatedPeople && selectedTask.relatedPeople.length > 0 && (
                        <p><strong className="text-muted-foreground">Người liên quan:</strong> <span className="text-foreground">{selectedTask.relatedPeople.join(', ')}</span></p>
                    )}
                </div>
                <div className="flex justify-end pt-4">
                    <Button variant="secondary" onClick={() => setSelectedTask(null)}>Đóng</Button>
                </div>
            </div>
        </Modal>
      )}
    </>
  );
};

export default TasksAndProjects;