
import React, { useState } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Modal from './ui/Modal';

interface LoginProps {
    onLogin: (email: string, pass: string) => boolean;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    
    // State for Forgot Password Modal
    const [isForgotPasswordOpen, setIsForgotPasswordOpen] = useState(false);
    const [forgotPasswordEmail, setForgotPasswordEmail] = useState('');
    const [forgotPasswordMessage, setForgotPasswordMessage] = useState('');


    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        const success = onLogin(email, password);
        if (!success) {
            setError('Email hoặc mật khẩu không chính xác.');
        }
    };
    
    const handleForgotPasswordSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // In a real app, you would trigger an API call here.
        // For this demo, we'll just show a confirmation message.
        setForgotPasswordMessage('Yêu cầu của bạn đã được gửi. Quản trị viên sẽ liên hệ để cấp lại mật khẩu.');
        
        // Optional: close the modal after a few seconds
        setTimeout(() => {
            setIsForgotPasswordOpen(false);
            // Reset states after closing
            setTimeout(() => {
                setForgotPasswordEmail('');
                setForgotPasswordMessage('');
            }, 300);
        }, 3000);
    };

    const formInputStyle = "mt-1 block w-full bg-input border border-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-ring text-foreground placeholder:text-muted-foreground transition-colors duration-200";

    return (
        <>
            <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-zinc-900 p-4">
                <Card className="max-w-md w-full">
                    <div className="text-center">
                        <h1 className="text-2xl font-bold text-primary tracking-wider mb-2">Lavis Brothers CRM</h1>
                        <h2 className="text-xl font-semibold text-foreground">Đăng nhập hệ thống</h2>
                        <p className="text-muted-foreground mt-1">Vui lòng nhập thông tin của bạn để tiếp tục.</p>
                    </div>
                    <form onSubmit={handleSubmit} className="mt-8 space-y-6">
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-muted-foreground">Địa chỉ Email</label>
                            <input
                                type="email"
                                name="email"
                                id="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className={formInputStyle}
                                placeholder="ban@email.com"
                                required
                            />
                        </div>
                        <div>
                            <label htmlFor="password"className="block text-sm font-medium text-muted-foreground">Mật khẩu</label>
                            <input
                                type="password"
                                name="password"
                                id="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                className={formInputStyle}
                                placeholder="••••••••"
                                required
                            />
                        </div>
                        
                        {error && (
                            <p className="text-sm text-red-500 text-center">{error}</p>
                        )}

                        <div>
                            <Button type="submit" className="w-full">
                                Đăng nhập
                            </Button>
                        </div>
                        <div className="text-center">
                            <button type="button" onClick={() => setIsForgotPasswordOpen(true)} className="text-sm text-muted-foreground hover:text-primary focus:outline-none">
                                Quên mật khẩu?
                            </button>
                        </div>
                    </form>
                </Card>
            </div>

            <Modal 
                isOpen={isForgotPasswordOpen} 
                onClose={() => setIsForgotPasswordOpen(false)} 
                title="Quên mật khẩu"
            >
                {forgotPasswordMessage ? (
                    <div className="text-center p-4">
                        <p className="text-base text-green-700 dark:text-green-400">{forgotPasswordMessage}</p>
                    </div>
                ) : (
                    <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
                        <p className="text-sm text-muted-foreground">Vui lòng nhập email của bạn. Một thông báo sẽ được gửi tới quản trị viên để hỗ trợ bạn cấp lại mật khẩu.</p>
                        <div>
                            <label htmlFor="forgot-email" className="block text-sm font-medium text-muted-foreground">Địa chỉ Email</label>
                            <input
                                type="email"
                                id="forgot-email"
                                value={forgotPasswordEmail}
                                onChange={(e) => setForgotPasswordEmail(e.target.value)}
                                className={formInputStyle}
                                placeholder="ban@email.com"
                                required
                            />
                        </div>
                        <div className="flex justify-end pt-4 space-x-2">
                            <Button type="button" variant="secondary" onClick={() => setIsForgotPasswordOpen(false)}>Hủy</Button>
                            <Button type="submit">Gửi yêu cầu</Button>
                        </div>
                    </form>
                )}
            </Modal>
        </>
    );
};

export default Login;
