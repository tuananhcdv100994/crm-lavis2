import React from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import { Deal, Task, Lead } from '../App';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';


interface ReportsProps {
  deals: Deal[];
  tasks: Task[];
  leads: Lead[];
}

const Reports: React.FC<ReportsProps> = ({ deals, tasks, leads }) => {
  const tickColor = 'hsl(var(--muted-foreground))';
  const gridColor = 'hsl(var(--border))';

  const salesSummary = deals.reduce((acc, deal) => {
    if (deal.stage === 'Thắng') {
      acc.wonCount += 1;
      acc.wonValue += deal.value;
    } else if (deal.stage === 'Thua') {
      acc.lostCount += 1;
    }
    acc.totalValue += deal.value;
    return acc;
  }, { wonCount: 0, wonValue: 0, lostCount: 0, totalValue: 0 });

  const tasksSummary = tasks.reduce((acc, task) => {
    acc[task.status] = (acc[task.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);
  
  const leadsSummary = leads.reduce((acc, lead) => {
    const item = acc.find(i => i.name === lead.status);
    if(item) {
        item.value += 1;
    } else {
        acc.push({ name: lead.status, value: 1 });
    }
    return acc;
  }, [] as { name: string, value: number }[]);

  const handleExport = () => {
    const salesData = [
      ['Chỉ số', 'Giá trị'],
      ['Cơ hội thắng', salesSummary.wonCount],
      ['Tổng giá trị thắng', `$${salesSummary.wonValue.toLocaleString()}`],
      ['Cơ hội thua', salesSummary.lostCount],
      ['Tổng giá trị pipeline', `$${salesSummary.totalValue.toLocaleString()}`]
    ];
    
    const tasksData = [
      ['Trạng thái công việc', 'Số lượng'],
      ...Object.entries(tasksSummary).map(([status, count]) => [status, count])
    ];

    const leadsData = [
        ['Trạng thái khách hàng', 'Số lượng'],
        ...leadsSummary.map(item => [item.name, item.value])
    ];

    const csvContent = [
      'Báo cáo hiệu suất kinh doanh',
      ...salesData.map(e => e.join(',')),
      '\n',
      'Báo cáo tổng quan công việc',
      ...tasksData.map(e => e.join(',')),
      '\n',
      'Báo cáo dữ liệu khách hàng',
      ...leadsData.map(e => e.join(','))
    ].join('\n');

    const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.setAttribute('download', 'bao_cao_tong_hop_crm.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-foreground">Bảng điều khiển Báo cáo</h2>
        <Button onClick={handleExport} variant="secondary">Tải báo cáo</Button>
      </div>
      
      <Card>
        <h3 className="text-xl font-semibold text-foreground mb-4">Hiệu suất kinh doanh</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-secondary p-4 rounded-lg"><p className="text-sm text-muted-foreground">Cơ hội thắng</p><p className="text-2xl font-bold text-green-600">{salesSummary.wonCount}</p></div>
            <div className="bg-secondary p-4 rounded-lg"><p className="text-sm text-muted-foreground">Tổng giá trị thắng</p><p className="text-2xl font-bold text-green-600">${salesSummary.wonValue.toLocaleString()}</p></div>
            <div className="bg-secondary p-4 rounded-lg"><p className="text-sm text-muted-foreground">Cơ hội thua</p><p className="text-2xl font-bold text-red-600">{salesSummary.lostCount}</p></div>
            <div className="bg-secondary p-4 rounded-lg"><p className="text-sm text-muted-foreground">Tổng giá trị pipeline</p><p className="text-2xl font-bold text-foreground">${salesSummary.totalValue.toLocaleString()}</p></div>
        </div>
      </Card>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <Card>
            <h3 className="text-lg font-semibold text-foreground mb-4">Tổng quan công việc</h3>
            <div className="bg-secondary p-4 rounded-lg">
                <table className="w-full">
                <tbody>
                    {Object.entries(tasksSummary).map(([status, count]) => (
                    <tr key={status} className="border-b border-border last:border-b-0">
                        <td className="py-2 pr-4 text-muted-foreground">{status}</td>
                        <td className="font-semibold text-foreground">{count}</td>
                    </tr>
                    ))}
                    <tr className="border-t-2 border-border"><td className="py-2 pr-4 text-foreground font-bold">Tổng số công việc</td><td className="font-bold text-foreground">{tasks.length}</td></tr>
                </tbody>
                </table>
            </div>
        </Card>
        <Card>
          <h3 className="text-lg font-semibold text-foreground mb-4">Phân loại khách hàng</h3>
           <div className="h-64 mt-4">
              <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={leadsSummary} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke={gridColor}/>
                        <XAxis dataKey="name" stroke={tickColor} tick={{ fill: tickColor }}/>
                        <YAxis stroke={tickColor} tick={{ fill: tickColor }}/>
                        <Tooltip
                            contentStyle={{ 
                            backgroundColor: 'hsl(var(--card))', 
                            border: `1px solid ${gridColor}`,
                            color: 'hsl(var(--card-foreground))'
                            }} 
                        />
                        <Bar dataKey="value" fill="#1d4ed8" name="Số lượng"/>
                  </BarChart>
              </ResponsiveContainer>
           </div>
        </Card>
      </div>
    </div>
  );
};

export default Reports;
