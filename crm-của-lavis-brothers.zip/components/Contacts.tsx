import React, { useState } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Modal from './ui/Modal';
import { Contact } from '../App';

interface ContactsProps {
    contacts: Contact[];
    onAddContact: (contact: Omit<Contact, 'id'>) => void;
}

const formInputStyle = "mt-1 block w-full bg-input border border-border rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-2 focus:ring-ring text-foreground placeholder:text-muted-foreground transition-colors duration-200";

const Contacts: React.FC<ContactsProps> = ({ contacts, onAddContact }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', company: '', email: '', phone: '', role: '' });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewContact(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddContact(newContact);
    setIsModalOpen(false);
    setNewContact({ name: '', company: '', email: '', phone: '', role: '' });
  };

  return (
    <>
      <Card>
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-foreground">Tất cả danh bạ</h2>
          <Button onClick={() => setIsModalOpen(true)}>Thêm liên hệ mới</Button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-secondary border-b border-border">
                <th className="p-3 text-sm font-semibold text-muted-foreground">Tên</th>
                <th className="p-3 text-sm font-semibold text-muted-foreground">Công ty</th>
                <th className="p-3 text-sm font-semibold text-muted-foreground">Email</th>
                <th className="p-3 text-sm font-semibold text-muted-foreground">Điện thoại</th>
                <th className="p-3 text-sm font-semibold text-muted-foreground">Chức vụ</th>
              </tr>
            </thead>
            <tbody>
              {contacts.map((contact) => (
                <tr key={contact.id} className="border-b border-border hover:bg-muted">
                  <td className="p-3 text-foreground">{contact.name}</td>
                  <td className="p-3 text-muted-foreground">{contact.company}</td>
                  <td className="p-3 text-muted-foreground">{contact.email}</td>
                  <td className="p-3 text-muted-foreground">{contact.phone}</td>
                  <td className="p-3 text-muted-foreground">{contact.role}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Thêm liên hệ mới">
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="name" className="block text-sm font-medium text-muted-foreground">Họ và tên</label>
            <input type="text" name="name" id="name" value={newContact.name} onChange={handleInputChange} className={formInputStyle} required />
          </div>
          <div>
            <label htmlFor="company" className="block text-sm font-medium text-muted-foreground">Công ty</label>
            <input type="text" name="company" id="company" value={newContact.company} onChange={handleInputChange} className={formInputStyle} />
          </div>
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-muted-foreground">Email</label>
            <input type="email" name="email" id="email" value={newContact.email} onChange={handleInputChange} className={formInputStyle} required />
          </div>
          <div>
            <label htmlFor="phone" className="block text-sm font-medium text-muted-foreground">Điện thoại</label>
            <input type="tel" name="phone" id="phone" value={newContact.phone} onChange={handleInputChange} className={formInputStyle} />
          </div>
          <div>
            <label htmlFor="role" className="block text-sm font-medium text-muted-foreground">Chức vụ</label>
            <input type="text" name="role" id="role" value={newContact.role} onChange={handleInputChange} className={formInputStyle} />
          </div>
          <div className="flex justify-end pt-4">
            <Button type="submit">Tạo liên hệ</Button>
          </div>
        </form>
      </Modal>
    </>
  );
};

export default Contacts;