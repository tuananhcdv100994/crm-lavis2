import React, { useState, useEffect } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import { AttendanceEntry } from '../App';

interface AttendanceProps {
  isCheckedIn: boolean;
  onToggleCheckIn: (location?: string) => void;
  log: AttendanceEntry[];
}

const Attendance: React.FC<AttendanceProps> = ({ isCheckedIn, onToggleCheckIn, log }) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [activeTab, setActiveTab] = useState('checkIn');

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCheckInWithLocation = () => {
    if (!navigator.geolocation) {
      alert('Trình duyệt của bạn không hỗ trợ định vị GPS.');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        const locationString = `${latitude.toFixed(4)}° N, ${longitude.toFixed(4)}° E`;
        onToggleCheckIn(locationString);
      },
      (error) => {
        alert(`Lỗi khi lấy vị trí: ${error.message}. Vui lòng cấp quyền truy cập vị trí trong cài đặt trình duyệt.`);
      }
    );
  }
  
  const TabButton: React.FC<{tabId: string; label: string}> = ({ tabId, label }) => (
    <button
        onClick={() => setActiveTab(tabId)}
        className={`px-4 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
            activeTab === tabId ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-accent'
        }`}
    >
        {label}
    </button>
  );

  return (
    <div className="space-y-6">
      <Card>
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="text-center md:text-left">
            <h2 className="text-2xl font-bold text-foreground">
              {currentTime.toLocaleTimeString()}
            </h2>
            <p className="text-muted-foreground">{currentTime.toLocaleDateString('vi-VN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
          </div>
          <div className="mt-4 md:mt-0 flex flex-col items-center space-y-2">
            <p className={`text-xl font-semibold ${isCheckedIn ? 'text-green-600' : 'text-yellow-600'}`}>
              {isCheckedIn ? 'Bạn đã Check In' : 'Bạn đã Check Out'}
            </p>
            {isCheckedIn ? (
                <Button onClick={() => onToggleCheckIn()} className="w-48" variant="destructive">Check Out</Button>
            ) : (
                <div className="flex space-x-2">
                    <Button onClick={() => onToggleCheckIn()} className="w-48" variant="secondary">Check In</Button>
                    <Button onClick={handleCheckInWithLocation} className="w-48">Check In với Vị trí</Button>
                </div>
            )}
          </div>
        </div>
      </Card>

      <Card>
        <div className="border-b border-border mb-6">
            <nav className="flex space-x-2">
                <TabButton tabId="checkIn" label="Chấm công (Web)" />
                <TabButton tabId="reports" label="Báo cáo hàng tháng" />
                <TabButton tabId="requests" label="Yêu cầu" />
                <TabButton tabId="teams" label="Xem theo nhóm" />
            </nav>
        </div>
        <div>
            {activeTab === 'checkIn' && (
                <div>
                    <h3 className="text-lg font-semibold text-foreground">Hoạt động hôm nay</h3>
                    {log.length > 0 ? (
                        <ul className="mt-4 space-y-2">
                            {log.map((entry, index) => (
                                <li key={index} className="flex justify-between p-3 bg-secondary rounded-md items-center">
                                    <div>
                                        <span className={`font-semibold ${entry.type === 'Check In' ? 'text-green-600' : 'text-yellow-700'}`}>{entry.type}</span>
                                        {entry.location && <span className="text-sm text-muted-foreground ml-4">tại {entry.location}</span>}
                                    </div>
                                    <span className="text-muted-foreground">{entry.time.toLocaleTimeString()}</span>
                                </li>
                            ))}
                        </ul>
                    ) : (
                        <p className="mt-2 text-muted-foreground">Hoạt động check-in/out của bạn trong ngày sẽ xuất hiện ở đây. Các tính năng GPS/QR có sẵn trên di động.</p>
                    )}
                </div>
            )}
            {activeTab === 'reports' && <div><h3 className="text-lg font-semibold text-foreground">Báo cáo chấm công hàng tháng</h3><p className="mt-2 text-muted-foreground">Xem và xuất file giờ làm việc và lịch sử chấm công hàng tháng của bạn.</p></div>}
            {activeTab === 'requests' && <div><h3 className="text-lg font-semibold text-foreground">Yêu cầu chỉnh sửa thời gian</h3><p className="mt-2 text-muted-foreground">Gửi yêu cầu điều chỉnh thời gian đã ghi nhận hoặc giải trình các sai lệch.</p></div>}
            {activeTab === 'teams' && <div><h3 className="text-lg font-semibold text-foreground">Chấm công theo nhóm</h3><p className="mt-2 text-muted-foreground">Xem chấm công theo ca hoặc nhóm nếu bạn là quản lý.</p></div>}
        </div>
      </Card>
    </div>
  );
};

export default Attendance;