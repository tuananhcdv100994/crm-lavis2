import React, { useState, useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import { SearchIcon, BellIcon } from './icons';
import { User, Notification } from '../App';

interface HeaderProps {
  currentUser: User;
  notifications: Notification[];
  setNotifications: React.Dispatch<React.SetStateAction<Notification[]>>;
}

const Header: React.FC<HeaderProps> = ({ notifications, setNotifications }) => {
  const location = useLocation();
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter(n => !n.read).length;
  
  const getTitle = () => {
    const path = location.pathname.split('/')[1];
    switch(path) {
        case 'dashboard': return 'Bảng điều khiển';
        case 'attendance': return 'Chấm công';
        case 'leads': return 'Khách hàng tiềm năng';
        case 'deals': return 'Cơ hội bán hàng';
        case 'contacts': return 'Danh bạ';
        case 'tasks-projects': return 'Công việc & Dự án';
        case 'reports': return 'Báo cáo';
        case 'settings': return 'Cài đặt';
        default: return 'Bảng điều khiển';
    }
  };
  
  const handleNotificationToggle = () => {
    setIsNotificationOpen(prev => !prev);
    if (!isNotificationOpen) { // When opening
        setTimeout(() => {
            setNotifications(prev => prev.map(n => ({...n, read: true})));
        }, 2000);
    }
  };
  
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setIsNotificationOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className="flex items-center justify-between h-20 px-6 bg-card border-b border-border">
      <h1 className="text-2xl font-bold text-foreground">{getTitle()}</h1>
      <div className="flex items-center space-x-4">
        <div className="relative">
          <SearchIcon className="absolute w-5 h-5 text-muted-foreground left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Tìm kiếm..."
            className="w-full pl-10 pr-4 py-2 border border-input bg-background rounded-lg focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
        <div className="relative" ref={notificationRef}>
            <button 
                onClick={handleNotificationToggle}
                className="relative p-2 text-muted-foreground rounded-full hover:bg-accent hover:text-accent-foreground focus:outline-none"
            >
                <BellIcon className="w-6 h-6"/>
                {unreadCount > 0 && (
                    <span className="absolute top-0 right-0 block h-2.5 w-2.5 rounded-full bg-red-500 ring-2 ring-white dark:ring-card"></span>
                )}
            </button>
            {isNotificationOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-card border border-border rounded-lg shadow-lg z-50">
                    <div className="p-3 font-semibold text-foreground border-b border-border">Thông báo</div>
                    <div className="py-1 max-h-96 overflow-y-auto">
                        {notifications.length > 0 ? notifications.map(notif => (
                             <div key={notif.id} className="px-4 py-3 hover:bg-accent">
                                <p className={`text-sm text-foreground ${!notif.read ? 'font-bold' : ''}`}>{notif.message}</p>
                                <p className="text-xs text-muted-foreground mt-1">{notif.time}</p>
                             </div>
                        )) : (
                            <div className="px-4 py-3 text-sm text-muted-foreground">Không có thông báo mới.</div>
                        )}
                    </div>
                </div>
            )}
        </div>
      </div>
    </header>
  );
};

export default Header;
